The input files for this level represent the following geographic areas:
1 - Austria
2 - South Africa
3 - Spain
4 - Brazil
